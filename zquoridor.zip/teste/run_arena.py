#!/usr/bin/env python3
import os
import sys
import json
import shutil
import argparse
import subprocess
import tempfile
import math
from concurrent.futures import ProcessPoolExecutor, as_completed

# ==============================================================================
# CONFIGURAÇÕES PADRÃO DO BENCHMARK (Altere aqui se preferir não usar CLI)
# ==============================================================================

# CONFIGURAÇÃO DE REFERÊNCIAS DO GIT PARA O CONFRONTO:
# - Se definir como None ou "", o script pega a VERSÃO ATUAL DA MÁQUINA (incluindo alterações não comitadas).
# - Exemplos de valores suportados:
#     GIT_REF1 = None          -> Versão local atual com alterações não comitadas
#     GIT_REF2 = "main"        -> Branch main do Git
#     GIT_REF2 = "v1.0"        -> Tag v1.0 do Git
#     GIT_REF2 = "HEAD"        -> Último commit da branch atual
#     GIT_REF2 = "HEAD~3"      -> 3 commits atrás
#     GIT_REF2 = "minha-branch"-> Outra branch
GIT_REF1 = None              # None = versão local não comitada (ou passe string de ref git)
GIT_REF2 = "main"            # Ref Git base para o confronto (ex: 'main', 'v1.0', 'HEAD')

GAMES = 1000                   # Quantidade total de jogos (serão divididos em pares com aberturas idênticas)
TIME_MS = 100                # Tempo de pensamento por lance em milissegundos
THREADS = 14                 # Número de núcleos / processos em paralelo (default 14)
RANDOM_OPENING_PLIES = 4     # Quantidade de lances aleatórios na abertura (duplicados por par)
SEED = 42                    # Semente aleatória
COMPILER = "g++"             # Compilador C++
CXX_FLAGS = "-O3 -std=c++17"  # Flags de compilação
# ==============================================================================

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BIN_DIR = os.path.join(PROJECT_ROOT, "teste", "bin")

def calculate_elo_and_ci(wins_1, wins_2, draws):
    total = wins_1 + wins_2 + draws
    if total == 0:
        return 0.0, 0.0
    
    score = (wins_1 + 0.5 * draws) / total
    if score <= 0.0:
        elo_diff = -800.0
    elif score >= 1.0:
        elo_diff = 800.0
    else:
        elo_diff = -400.0 * math.log10(1.0 / score - 1.0)
    
    p_w = wins_1 / total
    p_l = wins_2 / total
    p_d = draws / total
    
    variance = (p_w * (1.0 - score)**2 + p_l * (0.0 - score)**2 + p_d * (0.5 - score)**2)
    std_error = math.sqrt(variance / total) if total > 1 else 0.0
    
    if 0.0 < score < 1.0:
        factor = 400.0 / (math.log(10) * score * (1.0 - score))
        margin = 1.96 * std_error * factor
    else:
        margin = 0.0
        
    return elo_diff, margin

def compile_arena(src_dir, output_exe):
    os.makedirs(os.path.dirname(output_exe), exist_ok=True)
    arena_src = os.path.join(PROJECT_ROOT, "teste", "arena.cpp")
    cmd = f"{COMPILER} {CXX_FLAGS} -I\"{os.path.join(src_dir, 'src')}\" \"{arena_src}\" -o \"{output_exe}\""
    
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if res.returncode != 0:
        print(f"[!] ERRO DE COMPILAÇÃO em {src_dir}:\n{res.stderr}")
        sys.exit(1)

def prepare_engine_source(ref_name):
    """
    Se ref_name for None ou "", retorna o PROJECT_ROOT local com alterações atuais.
    Caso contrário, faz git worktree temporário da ref informada.
    """
    if not ref_name or ref_name.strip() == "":
        print(f"[*] Engine: Versao Local Atual (inclui alteracoes nao comitadas)")
        return PROJECT_ROOT, None
    else:
        temp_dir = tempfile.mkdtemp(prefix=f"zquoridor_ref_{ref_name.replace('/', '_')}_")
        print(f"[*] Engine: Criando git worktree temporario para '{ref_name}' em {temp_dir}")
        cmd = f"git worktree add --detach \"{temp_dir}\" {ref_name}"
        res = subprocess.run(cmd, shell=True, cwd=PROJECT_ROOT, capture_output=True, text=True)
        if res.returncode != 0:
            print(f"[!] ERRO ao criar worktree para git ref '{ref_name}':\n{res.stderr}")
            shutil.rmtree(temp_dir, ignore_errors=True)
            sys.exit(1)
        return temp_dir, temp_dir

def cleanup_worktree(temp_dir):
    if temp_dir and os.path.exists(temp_dir):
        print(f"[*] Removendo git worktree temporario {temp_dir}...")
        subprocess.run(f"git worktree remove --force \"{temp_dir}\"", shell=True, cwd=PROJECT_ROOT, capture_output=True)
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)

def run_worker_batch(exe_path, worker_games, time_ms, random_plies, seed):
    cmd = f"\"{exe_path}\" --games {worker_games} --time {time_ms} --random-plies {random_plies} --seed {seed}"
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    
    if res.returncode != 0:
        raise RuntimeError(f"Worker falhou: {res.stderr}")
        
    for line in res.stdout.splitlines():
        if line.startswith("RESULT_JSON:"):
            return json.loads(line.replace("RESULT_JSON:", "").strip())
            
    raise RuntimeError(f"Output invalido do worker: {res.stdout}")

def main():
    parser = argparse.ArgumentParser(description="Zquoridor Arena Selfplay: Confronto entre 2 Referencias Git ou Local")
    parser.add_argument("--ref1", default=GIT_REF1, help="Referencia Git do Engine 1 (deixe vazio/None para versao local)")
    parser.add_argument("--ref2", default=GIT_REF2, help="Referencia Git do Engine 2 (deixe vazio/None para versao local)")
    parser.add_argument("--games", type=int, default=GAMES, help=f"Total de jogos (padrao: {GAMES})")
    parser.add_argument("--time", type=int, default=TIME_MS, help=f"Tempo por lance em ms (padrao: {TIME_MS})")
    parser.add_argument("--threads", type=int, default=THREADS, help=f"Numero de nucleos/threads (padrao: {THREADS})")
    parser.add_argument("--random-plies", type=int, default=RANDOM_OPENING_PLIES, help=f"Lances aleatorios na abertura (padrao: {RANDOM_OPENING_PLIES})")
    parser.add_argument("--seed", type=int, default=SEED, help=f"Semente RNG (padrao: {SEED})")
    
    args = parser.parse_args()
    
    ref1_label = args.ref1 if args.ref1 else "LOCAL (Nao Comitado)"
    ref2_label = args.ref2 if args.ref2 else "LOCAL (Nao Comitado)"
    
    print("=" * 65)
    print("        ZQUORIDOR ARENA SELFPLAY - BENCHMARK MULTI-CORE")
    print("=" * 65)
    print(f"  Engine 1 : {ref1_label}")
    print(f"  Engine 2 : {ref2_label}")
    print(f"  Config   : {args.games} jogos | {args.threads} threads | {args.time}ms/lance | {args.random_plies} lances abertura")
    print("=" * 65 + "\n")
    
    # Prepara fontes e compilações
    dir1, cleanup1 = prepare_engine_source(args.ref1)
    dir2, cleanup2 = prepare_engine_source(args.ref2)
    
    cand_exe = os.path.join(BIN_DIR, "arena_engine1.exe")
    
    try:
        # Se forem os dois apontando para o mesmo dir local, compila uma vez
        print(f"[*] Compilando executavel de arena...")
        compile_arena(dir1, cand_exe)
        print(f"[+] Compilacao concluida com sucesso!")
    finally:
        cleanup_worktree(cleanup1)
        cleanup_worktree(cleanup2)
        
    # Divisão de partidas entre as threads/workers paralelas
    threads_count = max(1, args.threads)
    total_pairs = (args.games + 1) // 2
    pairs_per_thread = total_pairs // threads_count
    extra_pairs = total_pairs % threads_count
    
    tasks = []
    for w in range(threads_count):
        worker_pairs = pairs_per_thread + (1 if w < extra_pairs else 0)
        if worker_pairs <= 0:
            continue
        worker_games = worker_pairs * 2
        worker_seed = args.seed + w * 10007
        tasks.append((worker_games, worker_seed))
        
    print(f"\n[*] Disparando partidas em {len(tasks)} threads/processos paralelos...")
    
    tot_eng1_wins = 0
    tot_eng2_wins = 0
    tot_draws = 0
    tot_eng1_nodes = 0
    tot_eng2_nodes = 0
    tot_eng1_time = 0.0
    tot_eng2_time = 0.0
    
    completed_games = 0
    total_games = sum(t[0] for t in tasks)
    
    with ProcessPoolExecutor(max_workers=len(tasks)) as executor:
        futures = {
            executor.submit(run_worker_batch, cand_exe, g, args.time, args.random_plies, s): (g, s)
            for g, s in tasks
        }
        
        for future in as_completed(futures):
            res = future.result()
            tot_eng1_wins += res["candWins"]
            tot_eng2_wins += res["baseWins"]
            tot_draws += res["draws"]
            tot_eng1_nodes += res["candNodes"]
            tot_eng2_nodes += res["baseNodes"]
            tot_eng1_time += res["candTimeSec"]
            tot_eng2_time += res["baseTimeSec"]
            
            completed_games += futures[future][0]
            print(f"  Progresso: {completed_games:3d}/{total_games:3d} jogos concluidos. Engine 1: {tot_eng1_wins} | Engine 2: {tot_eng2_wins} | Empates: {tot_draws}")
    
    # Relatório estatístico
    if total_games > 0:
        elo_diff, elo_margin = calculate_elo_and_ci(tot_eng1_wins, tot_eng2_wins, tot_draws)
        eng1_nps = tot_eng1_nodes / tot_eng1_time if tot_eng1_time > 0 else 0.0
        eng2_nps = tot_eng2_nodes / tot_eng2_time if tot_eng2_time > 0 else 0.0
        
        print("\n" + "=" * 65)
        print("                  RELATORIO FINAL DE ELO & NODES/S")
        print("=" * 65)
        print(f"  Engine 1 ({ref1_label:^17}): {tot_eng1_wins:3d} vitorias ({100.0 * tot_eng1_wins / total_games:5.1f}%) | NPS: {eng1_nps:10,.0f} nps")
        print(f"  Engine 2 ({ref2_label:^17}): {tot_eng2_wins:3d} vitorias ({100.0 * tot_eng2_wins / total_games:5.1f}%) | NPS: {eng2_nps:10,.0f} nps")
        print(f"  Empates                     : {tot_draws:3d}          ({100.0 * tot_draws / total_games:5.1f}%)")
        print("-" * 65)
        sign = "+" if elo_diff >= 0 else ""
        print(f"  Diferenca Elo Engine 1 vs 2 : {sign}{elo_diff:.1f} (Margem ±{elo_margin:.1f})")
        if elo_diff > 0 and (elo_diff - elo_margin) > 0:
            print("  Status                      : [V] ENGINE 1 EH ESTATISTICAMENTE SUPERIOR!")
        elif elo_diff < 0 and (elo_diff + elo_margin) < 0:
            print("  Status                      : [X] ENGINE 2 EH ESTATISTICAMENTE SUPERIOR!")
        else:
            print("  Status                      : [~] DIFERENCA DENTRO DA MARGEM DE ERRO (Inconclusivo)")
        print("=" * 65 + "\n")

if __name__ == "__main__":
    main()
