#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <vector>
#include <random>
#include <string>
#include "rules.hpp"
#include "search.hpp"

using namespace qr;

// Executa uma única partida entre a versão local compilada neste binário e um motor.
// Caso este binário seja invocado pelo Python, ele joga o Engine1 vs Engine2.
int playArenaGame(int engine1PlayerIdx, int timeMs, const State& startState, uint64_t& eng1NodesOut, uint64_t& eng2NodesOut, double& eng1TimeOut, double& eng2TimeOut) {
    State s = startState;
    Negamax eng1;
    Negamax eng2;

    // Garantir zeramento e isolamento completo da TT entre partidas
    eng1.clearTT();
    eng2.clearTT();

    RepetitionTable realHistory;
    realHistory.push(s.hash);

    int maxPlies = 300;
    for (int ply = 0; ply < maxPlies; ply++) {
        int w = winner(s);
        if (w != -1) return w;

        if (realHistory.count(s.hash) >= 3) {
            return -1; // Empate por repetição
        }

        SearchStats st;
        Move m;
        auto t0 = std::chrono::high_resolution_clock::now();

        if (s.turn == engine1PlayerIdx) {
            m = eng1.chooseMove(s, 40, timeMs, st, realHistory);
            auto t1 = std::chrono::high_resolution_clock::now();
            eng1TimeOut += std::chrono::duration<double>(t1 - t0).count();
            eng1NodesOut += st.nodes;
        } else {
            RepetitionTable emptyHistory;
            m = eng2.chooseMove(s, 40, timeMs, st, emptyHistory);
            auto t1 = std::chrono::high_resolution_clock::now();
            eng2TimeOut += std::chrono::duration<double>(t1 - t0).count();
            eng2NodesOut += st.nodes;
        }

        s = applyMove(s, m);
        realHistory.push(s.hash);
    }
    return -1; // Limite de plies excedido
}

State generateRandomOpening(int randomPlies, std::mt19937_64& rng) {
    State s = initialState();
    for (int ply = 0; ply < randomPlies; ply++) {
        if (winner(s) != -1) break;
        auto moves = legalMoves(s);
        if (moves.empty()) break;
        std::uniform_int_distribution<size_t> pick(0, moves.size() - 1);
        s = applyMove(s, moves[pick(rng)]);
    }
    return s;
}

int main(int argc, char* argv[]) {
    int totalGames = 40;
    int timeMs = 10;
    int randomPlies = 4;
    uint64_t seed = 42;

    for (int i = 1; i < argc; i++) {
        if (std::strcmp(argv[i], "--games") == 0 && i + 1 < argc) {
            totalGames = std::atoi(argv[++i]);
        } else if (std::strcmp(argv[i], "--time") == 0 && i + 1 < argc) {
            timeMs = std::atoi(argv[++i]);
        } else if (std::strcmp(argv[i], "--random-plies") == 0 && i + 1 < argc) {
            randomPlies = std::atoi(argv[++i]);
        } else if (std::strcmp(argv[i], "--seed") == 0 && i + 1 < argc) {
            seed = std::stoull(argv[++i]);
        }
    }

    if (totalGames % 2 != 0) {
        totalGames++;
    }
    int totalPairs = totalGames / 2;

    std::mt19937_64 rng(seed);

    int eng1Wins = 0;
    int eng2Wins = 0;
    int draws = 0;
    uint64_t eng1Nodes = 0;
    uint64_t eng2Nodes = 0;
    double eng1TimeSec = 0.0;
    double eng2TimeSec = 0.0;

    for (int p = 0; p < totalPairs; p++) {
        State openingState = generateRandomOpening(randomPlies, rng);

        // Jogo A: Engine 1 = Jogador 0 (Brancas), Engine 2 = Jogador 1 (Pretas)
        int resA = playArenaGame(0, timeMs, openingState, eng1Nodes, eng2Nodes, eng1TimeSec, eng2TimeSec);
        if (resA == -1) draws++;
        else if (resA == 0) eng1Wins++;
        else eng2Wins++;

        // Jogo B: Engine 2 = Jogador 0 (Brancas), Engine 1 = Jogador 1 (Pretas) na MESMA abertura
        int resB = playArenaGame(1, timeMs, openingState, eng1Nodes, eng2Nodes, eng1TimeSec, eng2TimeSec);
        if (resB == -1) draws++;
        else if (resB == 1) eng1Wins++;
        else eng2Wins++;
    }

    double eng1Nps = eng1TimeSec > 0 ? eng1Nodes / eng1TimeSec : 0.0;
    double eng2Nps = eng2TimeSec > 0 ? eng2Nodes / eng2TimeSec : 0.0;

    std::printf("RESULT_JSON:{\"candWins\":%d,\"baseWins\":%d,\"draws\":%d,\"candNodes\":%llu,\"baseNodes\":%llu,\"candTimeSec\":%.4f,\"baseTimeSec\":%.4f,\"candNps\":%.0f,\"baseNps\":%.0f}\n",
                eng1Wins, eng2Wins, draws,
                (unsigned long long)eng1Nodes, (unsigned long long)eng2Nodes,
                eng1TimeSec, eng2TimeSec, eng1Nps, eng2Nps);
    std::fflush(stdout);

    return 0;
}

